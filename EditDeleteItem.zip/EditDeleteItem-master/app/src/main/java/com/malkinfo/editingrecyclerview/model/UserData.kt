package com.malkinfo.editingrecyclerview.model

data class UserData (
    var userName:String,
    var userMb:String
        )